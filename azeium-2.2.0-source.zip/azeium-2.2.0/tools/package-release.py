#!/usr/bin/env python3
"""Package a built Azeium release and exact-byte self-contained download pages."""
from pathlib import Path
import argparse
import base64
import hashlib
import json
import re
import shutil
import textwrap
import zipfile
import xml.etree.ElementTree as ET


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--version', default='1.9.2')
    parser.add_argument('--project', type=Path, default=Path('/workspace/my-codings-/lunge-test-client'))
    parser.add_argument('--folder', type=Path, default=Path('/workspace/artifacts/azeium-1.9.2'))
    parser.add_argument('--downloads', type=Path, default=Path('/workspace/my-codings-/downloads'))
    parser.add_argument('--preview', type=Path)
    parser.add_argument('--runtime-log', type=Path)
    args = parser.parse_args()
    version, project, folder = args.version, args.project, args.folder
    assert re.fullmatch(r'\d+\.\d+\.\d+', version), 'Invalid release version'
    prefix = f'azeium-{version}'
    name = f'{prefix}-mc1.21.11.jar'
    jar = project / 'build' / 'libs' / name
    jar_data = jar.read_bytes()
    sha = hashlib.sha256(jar_data).hexdigest()

    with zipfile.ZipFile(jar) as archive:
        metadata = json.loads(archive.read('fabric.mod.json'))
        mixins = json.loads(archive.read('lunge_test_client.mixins.json'))
        names = archive.namelist()
        assert metadata['version'] == version
        assert metadata['depends']['fabricloader'] == '>=0.19.3'
        assert metadata['depends']['mixinextras'] == '>=0.5.5'
        assert metadata['environment'] == 'client'
        assert len(mixins['client']) == 11 and 'CombatAttackMixin' in mixins['client']
        assert 'dev/lungetest/CombatAssistModule.class' in names
        assert 'dev/lungetest/mixin/CombatAttackMixin.class' in names
        assert not any('/verify/' in n or 'entityculling' in n.lower() for n in names)
        assert archive.read(metadata['icon']).startswith(b'\x89PNG\r\n\x1a\n')
        nested = 'META-INF/jars/mixinextras-fabric-0.5.5.jar'
        assert {'file': nested} in metadata['jars']
        assert hashlib.sha256(archive.read(nested)).hexdigest() == '5da883dc4bfb16e4ceca3f16d8c4ad937bdfb1ce337ed5ba15472d4d81dd6242'

    unit_suites = sorted((project / 'build/test-results/test').glob('TEST-*.xml'))
    assert unit_suites, 'Run the build and tests before packaging'
    unit_count = 0
    for unit in unit_suites:
        suite = ET.parse(unit).getroot()
        assert suite.get('failures') == '0' and suite.get('errors') == '0'
        unit_count += int(suite.get('tests'))
    runtime_counts = {}
    if args.runtime_log:
        runtime = args.runtime_log.read_text()
        for marker in ['KEYBINDS', 'LOCAL_COOLDOWN', 'MANUAL_ATTACK', 'PLAYER_HIGHLIGHT',
                       'PLAYER_TRACERS', 'AUTO_CLUTCH', 'CLUTCH_PLACEMENT',
                       'UTILITY_MODULES', 'QUICK_LUNGE', 'SURVIVAL_MODULES', 'COMBAT_ASSIST', 'TELLY_BRIDGE', 'AUTO_TELLY', 'CLIENT_SETTINGS', 'MENU_INTERACTION', 'GUI']:
            match = re.search(marker + r'_VERIFIED: (\d+)', runtime)
            assert match, 'Missing runtime evidence: ' + marker
            runtime_counts[marker] = int(match.group(1))
        assert 'GUI_RENDER_VERIFIED: 300 client ticks' in runtime
        assert 'GUI_CONFIG_RESTORED' in runtime and 'BUILD SUCCESSFUL' in runtime
        assert 'AssertionError' not in runtime and 'Mixin apply failed' not in runtime

    folder.mkdir(parents=True, exist_ok=True)
    args.downloads.mkdir(parents=True, exist_ok=True)
    shutil.copy2(jar, folder / name)
    shutil.copy2(project / 'README.md', folder / 'README.md')
    for unit in unit_suites:
        shutil.copy2(unit, folder / unit.name)
    if args.runtime_log and args.runtime_log.resolve() != (folder / 'runtime-verification.log').resolve():
        shutil.copy2(args.runtime_log, folder / 'runtime-verification.log')
    instructions = f'''Azeium {version} — Minecraft Java 1.21.11

1. Use Fabric Loader 0.19.3 or newer, Java 21 and Fabric API for Minecraft 1.21.11.
2. Remove your previous Azeium or spear-control JAR from this instance's mods folder.
3. Put {name} in that mods folder alongside Fabric API.
4. Launch Minecraft and press Right Shift, or your saved menu key.
5. Drag an empty header to move the menu. Movement keys work while open; typing and key capture pause movement.
6. The module sidebar has two pages. Use Previous/Next to see all fourteen modules.
   Spear has Quick-lunge key (one jab and return) and Spear slot (Auto or 1–9).
   Enable Spear first. Keep a Lunge enchanted spear for actual forward lunges.
   Added modules: Armor Alerts, Fullbright and Session HUD.
   Open Settings for Client, Themes and Test scenarios. Choose settings before starting trials.
   The shared UI retains darker glass, softened corners, quieter borders, smooth hover
   states, rounded switches/sliders and matching tooltips. Saved preferences are kept.
7. Traces save to logs/azeium-tests; server-only detection results need server logs.

AutoMace defaults to Falling smash (Action: Smash): while descending with more
than 1.5 blocks of real fall distance, an entity attack click switches to a hotbar
mace before that same hit. No second click or extra recharge delay is added.
Normal reach, visibility and item cooldowns apply. Keep a Wind Burst enchanted
mace to use that enchantment; the mod does not add it. Grounded/rising/short-fall
clicks keep their held item. Old Swap only preferences migrate once. Explicit
new Swap only and Charged follow-up choices remain available.
Auto Rejoin waits five seconds after a lost ordinary multiplayer connection and
stops after six retries. Going Back, cancelling or deliberately leaving stops it.
The Auto Rejoin tab includes Rejoin now and a separate saved Rejoin key. Its
regular module Keybind toggles Auto Rejoin. It starts OFF on launch.
The optional Charged follow-up mode selects a mace and sends one normally
charged strike against hostile mobs. Auto StunSlam starts an axe attack followed
by a normally charged mace strike when you manually hit a hostile mob. Keep an
axe and mace in your hotbar. Shield disabling follows normal vanilla rules.
Stun Slam always runs automatically on a manual hostile-mob hit and has no settings.
AutoMace may use Hold key mode with its Use key (default R). Module keybinds toggle ON/OFF.
Combat modules start OFF. Automated follow-ups are limited to hostile mobs.

For jump bridging, press Right Shift, choose Auto Clutch and enable it:
- Telly only places normally supported, reachable bridge blocks throughout
  jumps without automatic water or falling-block clutch actions.
- Telly bridge + clutch adds the existing falling-block/water fallback.
- Bridge speed offers budgets of 1, 2 or 4 placement attempts per game tick.
  Fast (4/tick) is the default for Telly modes. Failed attempts count too; four
  attempts do not guarantee four placed blocks. These are normal vanilla
  interactions; higher frame rates do not raise the per-tick budget.
Start on a solid bridge block and keep solid blocks in your hotbar/offhand.
Keep a filled water bucket available when using Telly bridge + clutch.
Blocks + water remains the overall default mode. Telly retries are bounded.
Severe lag, unavailable support or server rejection can still prevent placing.

This release retains bundled MixinExtras 0.5.5 for the startup compatibility fix.
The ZIP itself does not go in mods. Extract the JAR first.
'''
    (folder / 'INSTALL.txt').write_text(instructions)
    install = folder / f'{prefix}-install.zip'
    with zipfile.ZipFile(install, 'w', zipfile.ZIP_DEFLATED) as archive:
        archive.writestr(name, jar_data)
        archive.writestr('INSTALL.txt', instructions)
    with zipfile.ZipFile(install) as archive:
        assert archive.read(name) == jar_data

    source = folder / f'{prefix}-source.zip'
    source_files = []
    with zipfile.ZipFile(source, 'w', zipfile.ZIP_DEFLATED) as archive:
        for root_name in ['src', 'gradle']:
            for path in sorted((project / root_name).rglob('*')):
                if path.is_file():
                    relative = path.relative_to(project)
                    archive.write(path, Path(prefix) / relative)
                    source_files.append(str(relative))
        for filename in ['README.md', 'LICENSE', 'build.gradle', 'settings.gradle',
                         'gradle.properties', 'gradlew', 'gradlew.bat']:
            archive.write(project / filename, Path(prefix) / filename)
            source_files.append(filename)
        probe = Path('/workspace/artifacts/azeium-startup/RedirectCompatibilityProbe.java')
        if probe.exists():
            archive.write(probe, Path(prefix) / 'verification' / probe.name)
        archive.writestr(str(Path(prefix) / 'verification' / 'STARTUP-COMPATIBILITY.md'),
                         'The MixinExtras 0.5.5 compatibility fix from Azeium 1.8.1 remains included.\n'
                         'RedirectCompatibilityProbe.java reproduces the older library array-cast failure.\n')
        archive.writestr(str(Path(prefix) / 'tools' / 'package-release.py'), Path(__file__).read_text())
    with zipfile.ZipFile(source) as archive:
        for filename in source_files:
            assert archive.read(str(Path(prefix) / filename)) == (project / filename).read_bytes()

    zip_data = install.read_bytes()
    preview = ''
    if args.preview:
        assert args.preview.read_bytes().startswith(b'\x89PNG\r\n\x1a\n')
        preview = '<img alt="Actual Azeium module menu" src="data:image/png;base64,' + base64.b64encode(args.preview.read_bytes()).decode() + '">'
    common_style = '''
:root{color-scheme:dark}*{box-sizing:border-box}body{margin:0;background:radial-gradient(ellipse at top,#322647,#0c1222 70%);color:#edf3ff;font:16px/1.6 system-ui,sans-serif}main{max-width:680px;margin:6vh auto;padding:26px}header{color:#cbb7ff;font-size:34px;font-weight:800;letter-spacing:-1px}h1{line-height:1.2;font-size:28px}p,li{color:#b9c7df}section{border:1px solid #46516d;border-radius:22px;background:#ffffff08;box-shadow:0 20px 70px #0004;padding:24px;margin:24px 0}a.download{display:block;padding:16px;border-radius:13px;text-align:center;background:#c1acff;color:#1b1232;text-decoration:none;font-weight:750;margin:12px 0}a.secondary{background:#253149;border:1px solid #58637a;color:#edf3ff}a:focus-visible{outline:3px solid #7bebef;outline-offset:4px}.ready{color:#a1ecd0;font-size:14px}.hint,footer{font-size:14px}code{overflow-wrap:anywhere;font-size:12px;color:#c9b5ff}kbd{border:1px solid #7583a0;border-radius:4px;padding:2px 5px}img{width:100%;border-radius:20px;border:1px solid #58637a}ol{padding-left:22px}li{margin:8px 0}
'''
    page = f'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Azeium {version} download</title><style>{common_style}</style></head><body><main>
<header>azeium</header><h1>Version {version}</h1><p>Minecraft Java <strong>1.21.11</strong> · Fabric Loader <strong>0.19.3+</strong> · Fabric API</p>
<section aria-label="Downloads"><a class="download" id="jar-download" href="data:application/octet-stream;base64,{base64.b64encode(jar_data).decode()}" download="{name}">Download mod (.jar)</a>
<a class="download secondary" id="zip-download" href="data:application/zip;base64,{base64.b64encode(zip_data).decode()}" download="{prefix}-install.zip">Download install ZIP</a><div class="ready" id="status" role="status">Open this HTML file in a browser to download.</div>
<p class="hint">Save this page as an HTML file and open it in Chrome, Edge or Firefox. The full JAR and ZIP are included in this page.</p><noscript><p class="hint">JavaScript is disabled; the buttons use direct embedded download links.</p></noscript></section>
{preview}<h2>Install</h2><ol><li>Remove the previous Azeium JAR from your Minecraft instance's <code>mods</code> folder.</li><li>Put <code>{name}</code> in that folder alongside Fabric API. Extract the ZIP first if you choose it.</li><li>Launch Minecraft and press <kbd>Right Shift</kbd>. Use Previous/Next for all fourteen modules. In Spear, enable the module, assign Quick-lunge key and keep a spear in the hotbar. One press selects it, jabs and returns to your old slot. Real lunges need the Lunge enchantment and vanilla server acceptance. Open Settings for themes and client preferences.</li><li>AutoMace defaults to Falling smash: while descending with more than 1.5 blocks of fall distance, your attack click switches to the hotbar mace before that same hit. Keep an axe too for Auto StunSlam.</li><li>For jump bridging, select Auto Clutch and choose Telly only, or Telly bridge + clutch for water fallback. Bridge speed allows up to 1, 2 or 4 placement attempts per game tick, including failed attempts.</li></ol>
<p>Smooth Open Sans menus with draggable headers and movement while open. Six gradient presets and custom colours apply throughout the menu and HUD. Test scenarios include finite Shield Drainer trials, reaction delays, action intervals and JSONL observations in <code>logs/azeium-tests</code>. Flag/No flag buttons add your annotations; server-only alerts need server logs.</p><footer>AutoMace Falling smash selects your hotbar mace before the same manual falling attack click. Auto Rejoin includes a separate saved Rejoin key. Auto StunSlam sends an axe hit followed by a normally charged mace strike. Both start OFF. Auto Clutch includes Telly only and Telly bridge + clutch, with adjustable bridge speed. Includes MixinExtras 0.5.5 for the startup compatibility fix.</footer><details><summary>Verify the JAR</summary><p>SHA-256:<br><code>{sha}</code></p></details></main><script>
(() => {{
 const links=[document.getElementById('jar-download'),document.getElementById('zip-download')];
 const originals=links.map(link=>link.getAttribute('href'));const urls=[];const lengths=[{len(jar_data)},{len(zip_data)}];
 try {{links.forEach((link,index)=>{{const decoded=atob(originals[index].split(',')[1]);if(decoded.length!==lengths[index])throw new Error('Incomplete payload');const bytes=new Uint8Array(decoded.length);for(let i=0;i<decoded.length;i++)bytes[i]=decoded.charCodeAt(i);const url=URL.createObjectURL(new Blob([bytes],{{type:index===0?'application/octet-stream':'application/zip'}}));urls.push(url);link.href=url;}});document.getElementById('status').textContent='Ready — choose JAR or ZIP above.';}}
 catch(error) {{urls.forEach(url=>URL.revokeObjectURL(url));links.forEach((link,index)=>link.href=originals[index]);document.getElementById('status').textContent='Direct links available. Open the saved HTML file in your browser.';}}
}})();
</script></body></html>'''
    full_page = folder / f'{prefix}-download.html'
    full_page.write_text(page)
    wrapped = '\n'.join(textwrap.wrap(base64.b64encode(jar_data).decode(), 120))
    recovery = f'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Azeium {version} recovery download</title><style>{common_style}</style></head><body><main><header>azeium</header><h1>Version {version}</h1><p>Minecraft Java 1.21.11 · Fabric Loader 0.19.3+ · Fabric API</p><section><a class="download" id="download" href="#" download="{name}">Download the mod JAR</a><p class="ready" id="status" role="status">Preparing your file…</p><noscript><p>Enable JavaScript to prepare the embedded JAR download.</p></noscript></section><p>This page contains the full mod JAR. Save the entire HTML source as <strong>Azeium.html</strong> using Notepad's <strong>All Files</strong> option, then open that file in Chrome, Edge or Firefox.</p><p>Replace your previous Azeium JAR in the instance's mods folder. Includes quick-lunge action key, Armor Alerts, Fullbright, Session HUD, falling AutoMace, Auto Rejoin, Auto StunSlam, Telly only, adjustable bridge speed and bundled MixinExtras 0.5.5.</p><details><summary>SHA-256</summary><code>{sha}</code></details></main>
<script id="payload" type="application/octet-stream">
{wrapped}
</script><script>
(() => {{
 const status=document.getElementById('status');const link=document.getElementById('download');
 try {{const encoded=document.getElementById('payload').textContent.replace(/\\s/g,'');const decoded=atob(encoded);if(decoded.length!=={len(jar_data)})throw new Error('Incomplete JAR payload');const bytes=new Uint8Array(decoded.length);for(let i=0;i<decoded.length;i++)bytes[i]=decoded.charCodeAt(i);link.href=URL.createObjectURL(new Blob([bytes],{{type:'application/octet-stream'}}));status.textContent='Ready — click Download the mod JAR.';}}
 catch(error) {{link.removeAttribute('href');status.textContent='Incomplete file: copy the entire HTML source and save it again.';}}
}})();
</script></body></html>'''
    recovery_page = folder / f'{prefix}-download-recovery.html'
    recovery_page.write_text(recovery)
    manifest = {'version':version,'jar':name,'bytes':len(jar_data),'sha256':sha,
                'source_project_files':source_files,'unit_tests':unit_count,
                'runtime_check_counts':runtime_counts,
                'nested_mixinextras_version':'0.5.5','required_mixins':mixins['client']}
    (folder / 'release-packaging.json').write_text(json.dumps(manifest, indent=2)+'\n')
    outputs = [folder / name, install, source, full_page, recovery_page]
    (folder / 'SHA256SUMS.txt').write_text(''.join(f'{hashlib.sha256(path.read_bytes()).hexdigest()}  {path.name}\n' for path in outputs))
    for path in outputs:
        path.chmod(0o644)
        destination = args.downloads / path.name
        shutil.copy2(path, destination)
        destination.chmod(0o644)
        print(f'{path.name}: {path.stat().st_size} bytes')
    shutil.copy2(folder / 'INSTALL.txt', args.downloads / f'{prefix}-INSTALL.txt')
    (args.downloads / f'{prefix}-INSTALL.txt').chmod(0o644)
    print('JAR SHA-256:',sha)
    print('Source project files:',len(source_files))
    print('Nested MixinExtras 0.5.5 retained; 11 required production mixins; fixture classes excluded.')


if __name__ == '__main__':
    main()
