import com.llamalad7.mixinextras.wrapper.factory.FactoryRedirectWrapperMixinTransformer;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.Type;
import org.objectweb.asm.tree.AnnotationNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.MethodNode;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * Isolated compatibility check using the trusted dependency jars, with no game
 * launch, game class loading, or third-party client mod execution. Compile with
 * Sponge Mixin 0.17.4 so the Java compiler emits real Redirect.at annotation
 * arrays; the legacy single-at checks only change that one ASM value.
 */
public final class RedirectCompatibilityProbe {
    private static final String REDIRECT = Type.getDescriptor(Redirect.class);
    private static final String INJECT = Type.getDescriptor(Inject.class);
    private static final String WRAPPER =
            "Lcom/llamalad7/mixinextras/wrapper/factory/FactoryRedirectWrapper;";

    private static int checks;
    private static int expectedFailures;

    public static void main(String[] args) throws Exception {
        if (args.length != 1 || !(args[0].equals("0.5.4") || args[0].equals("0.5.5"))) {
            throw new IllegalArgumentException("Usage: RedirectCompatibilityProbe 0.5.4|0.5.5");
        }
        boolean oldExtras = args[0].equals("0.5.4");
        System.out.println("MixinExtras " + args[0]);
        System.out.println("Transformer source: " +
                FactoryRedirectWrapperMixinTransformer.class.getProtectionDomain()
                        .getCodeSource().getLocation());
        System.out.println("Sponge Mixin source: " +
                Redirect.class.getProtectionDomain().getCodeSource().getLocation());
        System.out.println("Redirect.at Java type: " +
                Redirect.class.getDeclaredMethod("at").getReturnType().getTypeName());
        if (Redirect.class.getDeclaredMethod("at").getReturnType() != At[].class) {
            throw new AssertionError("This probe requires Sponge Mixin 0.17.4 array annotations");
        }

        check("array INVOKE", "arrayInvoke", false, false, oldExtras);
        check("array NEW", "arrayNew", false, true, oldExtras);
        check("array INVOKE then NEW", "arrayInvokeThenNew", false, true, oldExtras);
        check("array NEW then INVOKE", "arrayNewThenInvoke", false, true, oldExtras);
        check("legacy single INVOKE", "arrayInvoke", true, false, false);
        check("legacy single NEW", "arrayNew", true, true, false);
        check("Inject array RETURN control", "arrayInjectReturn", false, false, false);

        System.out.println("PASS: " + checks + " checks; " + expectedFailures +
                " expected compatibility exceptions reproduced; no unexpected failures");
    }

    private static void check(String label, String methodName, boolean legacySingle,
                              boolean expectWrapped, boolean expectClassCast) throws Exception {
        ClassNode parsed = new ClassNode();
        String resource = "/" + Fixtures.class.getName().replace('.', '/') + ".class";
        try (InputStream input = RedirectCompatibilityProbe.class.getResourceAsStream(resource)) {
            if (input == null) throw new AssertionError("Missing compiled fixture " + resource);
            new ClassReader(input).accept(parsed, 0);
        }
        MethodNode method = parsed.methods.stream().filter(m -> m.name.equals(methodName))
                .findFirst().orElseThrow();
        parsed.methods = new ArrayList<>(List.of(method));
        AnnotationNode original = method.visibleAnnotations.stream()
                .filter(a -> a.desc.equals(REDIRECT) || a.desc.equals(INJECT))
                .findFirst().orElseThrow();
        int atIndex = original.values.indexOf("at") + 1;
        if (atIndex < 1) throw new AssertionError("Missing at annotation");
        Object rawAt = original.values.get(atIndex);
        if (!(rawAt instanceof ArrayList<?> atList) || atList.isEmpty()
                || !(atList.getFirst() instanceof AnnotationNode)) {
            throw new AssertionError("Compiler did not produce an ASM ArrayList of At annotations");
        }
        if (legacySingle) original.values.set(atIndex, ((List<?>) rawAt).getFirst());
        String inputType = original.values.get(atIndex).getClass().getName();

        try {
            new FactoryRedirectWrapperMixinTransformer().transform(null, parsed);
        } catch (ClassCastException failure) {
            if (!expectClassCast || !failure.getMessage().contains("java.util.ArrayList")
                    || !failure.getMessage().contains("org.objectweb.asm.tree.AnnotationNode")
                    || !failure.getStackTrace()[0].getClassName().equals(
                    FactoryRedirectWrapperMixinTransformer.class.getName())) {
                throw failure;
            }
            expectedFailures++;
            checks++;
            System.out.println("EXPECTED FAILURE " + label + " [at=" + inputType + "]: " + failure);
            System.out.println("  at " + failure.getStackTrace()[0]);
            return;
        }
        if (expectClassCast) throw new AssertionError(label + " should reproduce the 0.5.4 exception");

        boolean wrapped = method.visibleAnnotations.stream().anyMatch(a -> a.desc.equals(WRAPPER));
        if (wrapped != expectWrapped) {
            throw new AssertionError(label + ": expected wrapped=" + expectWrapped + ", got " + wrapped);
        }
        if (wrapped) {
            AnnotationNode wrapper = method.visibleAnnotations.stream()
                    .filter(a -> a.desc.equals(WRAPPER)).findFirst().orElseThrow();
            if (wrapper.values.get(wrapper.values.indexOf("original") + 1) != original
                    || method.visibleAnnotations.contains(original)) {
                throw new AssertionError(label + ": NEW redirect did not retain the original annotation");
            }
        } else if (!method.visibleAnnotations.contains(original)) {
            throw new AssertionError(label + ": transformer unexpectedly removed injector annotation");
        }
        checks++;
        System.out.println("PASS " + label + " [at=" + inputType + ", wrapped=" + wrapped + "]");
    }

    private static final class Fixtures {
        @Redirect(method = "target", at = @At("INVOKE"))
        private void arrayInvoke() {}

        @Redirect(method = "target", at = @At("NEW"))
        private void arrayNew() {}

        @Redirect(method = "target", at = {@At("INVOKE"), @At("NEW")})
        private void arrayInvokeThenNew() {}

        @Redirect(method = "target", at = {@At("NEW"), @At("INVOKE")})
        private void arrayNewThenInvoke() {}

        @Inject(method = "target", at = @At("RETURN"))
        private void arrayInjectReturn() {}
    }
}
