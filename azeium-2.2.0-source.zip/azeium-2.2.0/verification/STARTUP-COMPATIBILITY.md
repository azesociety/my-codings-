The MixinExtras 0.5.5 compatibility fix from Azeium 1.8.1 remains included.
RedirectCompatibilityProbe.java reproduces the older library array-cast failure.
